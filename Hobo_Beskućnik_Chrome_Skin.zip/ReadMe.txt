############################################################
#                                                          #
#            HOBO BESKUĆNIK - GOOGLE CHROME SKIN           #
#                  (c) 2026 MALIŠANI                       #
#                                                          #
############################################################

Čestitamo! Upravo ste preuzeli najprljaviji skin za vaš 
Google Chrome. Ako vam se nakon instalacije na ekranu 
pojave mrlje od kave ili miris jeftinih cigareta - 
to nije bug, to je FEATURE.

------------------------------------------------------------
>>> KAKO INSTALIRATI (Pročitaj ili ćeš požaliti) <<<
------------------------------------------------------------

1. Raspakiraj ovaj ZIP negdje gdje ga nećeš izgubiti 
   (npr. Desktop, odmah pored ikone za Solitaire).
2. Otvori Google Chrome i upiši: chrome://extensions/
3. U gornjem desnom kutu upali "Developer mode".
4. Klikni na "Load unpacked" (Učitaj raspakirano).
5. Odaberi mapu u kojoj se nalazi ovaj ReadMe.
6. Potvrdi i uživaj u pogledu.

------------------------------------------------------------
>>> NAPOMENA <<<
------------------------------------------------------------
Skin je testiran na prljavim monitorima i radi savršeno. 
Mališani produkcija ne odgovara za duševne boli tvoje babe 
kad vidi tvoj preglednik.

------------------------------------------------------------
Hvala što podržavate Hobu. 
Sada se vrati na posao ili idi kartu igrat.

(c) 2026 Mališani Produkcija